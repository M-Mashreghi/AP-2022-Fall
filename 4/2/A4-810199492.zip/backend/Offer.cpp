#include "Offer.hpp"


int Offer::offer_id = 1;