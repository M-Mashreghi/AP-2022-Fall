#include "Purchased_card.hpp"
int Purchased_card::current_registerd_purchased_card = 1;