#include "UTkala.hpp"

using namespace std;


int main() {
	UTkala UTKALA;
	UTKALA.run();
}