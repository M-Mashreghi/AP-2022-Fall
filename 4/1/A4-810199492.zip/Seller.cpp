
#include "Seller.hpp"

using namespace std;

Seller::Seller(string _username, string _password, string _city) : User(_username, _password, _city) {}
